// Matrix Tracing: paths in an m x n grid = C(m+n-2, m-1) mod 1e9+7
#include <stdio.h>
#define MOD 1000000007ULL
#define MAXN 2000005

static unsigned long long fact[MAXN], inv_fact[MAXN];

unsigned long long power(unsigned long long b, unsigned long long e) {
    unsigned long long r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    fact[0] = 1;
    for (int i = 1; i < MAXN; i++) fact[i] = fact[i - 1] * i % MOD;
    inv_fact[MAXN - 1] = power(fact[MAXN - 1], MOD - 2);
    for (int i = MAXN - 1; i > 0; i--) inv_fact[i - 1] = inv_fact[i] * i % MOD;

    int t;
    scanf("%d", &t);
    while (t--) {
        int m, n;
        scanf("%d %d", &m, &n);
        int N = m + n - 2, r = m - 1;
        printf("%llu\n", fact[N] * inv_fact[r] % MOD * inv_fact[N - r] % MOD);
    }
    return 0;
}
