// Simple Array Sum
#include <stdio.h>
int main() {
    int n; long long sum = 0, x;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) { scanf("%lld", &x); sum += x; }
    printf("%lld\n", sum);
    return 0;
}
