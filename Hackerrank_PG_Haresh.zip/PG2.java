// Java Datatypes
import java.math.BigInteger;
import java.util.Scanner;

class Solution {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while (t-- > 0) {
            String s = sc.next();
            try {
                BigInteger x = new BigInteger(s);
                boolean b = x.compareTo(BigInteger.valueOf(Byte.MIN_VALUE)) >= 0 && x.compareTo(BigInteger.valueOf(Byte.MAX_VALUE)) <= 0;
                boolean sh = x.compareTo(BigInteger.valueOf(Short.MIN_VALUE)) >= 0 && x.compareTo(BigInteger.valueOf(Short.MAX_VALUE)) <= 0;
                boolean in = x.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) >= 0 && x.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) <= 0;
                boolean lo = x.compareTo(BigInteger.valueOf(Long.MIN_VALUE)) >= 0 && x.compareTo(BigInteger.valueOf(Long.MAX_VALUE)) <= 0;
                if (!lo) {
                    System.out.println(s + " can't be fitted anywhere.");
                } else {
                    System.out.println(s + " can be fitted in:");
                    if (b) System.out.println("* byte");
                    if (sh) System.out.println("* short");
                    if (in) System.out.println("* int");
                    System.out.println("* long");
                }
            } catch (Exception e) {
                System.out.println(s + " can't be fitted anywhere.");
            }
        }
        sc.close();
    }
}
