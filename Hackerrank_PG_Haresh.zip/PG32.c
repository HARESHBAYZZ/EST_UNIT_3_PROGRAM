// Counting Sort 1
#include <stdio.h>
int main() {
    int n, x, count[100] = {0};
    scanf("%d", &n);
    for (int i = 0; i < n; i++) { scanf("%d", &x); count[x]++; }
    for (int i = 0; i < 100; i++) printf("%d ", count[i]);
    printf("\n");
    return 0;
}
