// Small Triangles, Large Triangles (sort triangles by area)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct triangle {
    int a, b, c;
};

double area(struct triangle t) {
    double p = (t.a + t.b + t.c) / 2.0;
    return sqrt(p * (p - t.a) * (p - t.b) * (p - t.c));
}

void sort_by_area(struct triangle *tr, int n) {
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - 1 - i; j++)
            if (area(tr[j]) > area(tr[j + 1])) {
                struct triangle tmp = tr[j];
                tr[j] = tr[j + 1];
                tr[j + 1] = tmp;
            }
}

int main() {
    int n;
    scanf("%d", &n);
    struct triangle *tr = malloc(n * sizeof(struct triangle));
    for (int i = 0; i < n; i++) scanf("%d %d %d", &tr[i].a, &tr[i].b, &tr[i].c);
    sort_by_area(tr, n);
    for (int i = 0; i < n; i++) printf("%d %d %d\n", tr[i].a, tr[i].b, tr[i].c);
    free(tr);
    return 0;
}
