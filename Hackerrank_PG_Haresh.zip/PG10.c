// For Loop
#include <stdio.h>
int main() {
    const char *w[] = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
    int a, b;
    scanf("%d\n%d", &a, &b);
    for (int n = a; n <= b; n++) {
        if (n <= 9) printf("%s\n", w[n]);
        else printf(n % 2 == 0 ? "even\n" : "odd\n");
    }
    return 0;
}
