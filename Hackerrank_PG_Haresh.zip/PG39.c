// Restaurant (largest equal square pieces of an l x b cake)
#include <stdio.h>

long long gcd(long long a, long long b) { return b == 0 ? a : gcd(b, a % b); }

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        long long l, b;
        scanf("%lld %lld", &l, &b);
        long long g = gcd(l, b);
        printf("%lld\n", (l / g) * (b / g));
    }
    return 0;
}
