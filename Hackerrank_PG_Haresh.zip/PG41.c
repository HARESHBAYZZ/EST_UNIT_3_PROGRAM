// Project Euler #7: 10001st prime (n-th prime using a sieve)
#include <stdio.h>
#include <string.h>
#define LIMIT 110000

int main() {
    static char composite[LIMIT + 1];
    static int primes[LIMIT];
    int cnt = 0;
    for (int i = 2; i <= LIMIT; i++) {
        if (!composite[i]) {
            primes[cnt++] = i;
            for (long long j = (long long)i * i; j <= LIMIT; j += i) composite[j] = 1;
        }
    }
    int t, n;
    scanf("%d", &t);
    while (t--) {
        scanf("%d", &n);
        printf("%d\n", primes[n - 1]);
    }
    return 0;
}
