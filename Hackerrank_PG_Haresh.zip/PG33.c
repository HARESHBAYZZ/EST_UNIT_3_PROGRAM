// Counting Sort 2
#include <stdio.h>
int main() {
    int n, x, count[100] = {0};
    scanf("%d", &n);
    for (int i = 0; i < n; i++) { scanf("%d", &x); count[x]++; }
    for (int i = 0; i < 100; i++)
        for (int j = 0; j < count[i]; j++) printf("%d ", i);
    printf("\n");
    return 0;
}
