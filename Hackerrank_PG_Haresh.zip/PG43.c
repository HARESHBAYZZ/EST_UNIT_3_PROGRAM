// Summing the N Series: sum of (k^2 - (k-1)^2) for k = 1..n  =  n^2 (mod 1e9+7)
#include <stdio.h>
#define MOD 1000000007ULL

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        unsigned long long n;
        scanf("%llu", &n);
        n %= MOD;
        printf("%llu\n", (n * n) % MOD);
    }
    return 0;
}
