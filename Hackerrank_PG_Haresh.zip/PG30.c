// Max Min (sliding window over sorted array)
#include <stdio.h>
#include <stdlib.h>
int cmp(const void *a, const void *b) {
    return *(const int *)a - *(const int *)b;
}
int main() {
    int n, k;
    scanf("%d %d", &n, &k);
    int *a = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    qsort(a, n, sizeof(int), cmp);
    int best = a[k - 1] - a[0];
    for (int i = 1; i + k - 1 < n; i++) {
        int d = a[i + k - 1] - a[i];
        if (d < best) best = d;
    }
    printf("%d\n", best);
    free(a);
    return 0;
}
