// nCr Table: print C(n,0) .. C(n,n) modulo 1e9 for each test
#include <stdio.h>
#define MOD 1000000000LL

static long long c[1001][1001];

int main() {
    for (int i = 0; i <= 1000; i++) {
        c[i][0] = 1;
        for (int j = 1; j <= i; j++)
            c[i][j] = (c[i - 1][j - 1] + (j <= i - 1 ? c[i - 1][j] : 0)) % MOD;
    }
    int t, n;
    scanf("%d", &t);
    while (t--) {
        scanf("%d", &n);
        for (int j = 0; j <= n; j++) printf("%lld ", c[n][j]);
        printf("\n");
    }
    return 0;
}
