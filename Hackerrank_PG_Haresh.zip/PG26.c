// Dynamic Array
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *data;
    int size, cap;
} Seq;

int main() {
    int n, q, last = 0;
    scanf("%d %d", &n, &q);
    Seq *seq = calloc(n, sizeof(Seq));
    while (q--) {
        int type, x, y;
        scanf("%d %d %d", &type, &x, &y);
        int idx = (x ^ last) % n;
        if (type == 1) {
            if (seq[idx].size == seq[idx].cap) {
                seq[idx].cap = seq[idx].cap ? seq[idx].cap * 2 : 4;
                seq[idx].data = realloc(seq[idx].data, seq[idx].cap * sizeof(int));
            }
            seq[idx].data[seq[idx].size++] = y;
        } else {
            last = seq[idx].data[y % seq[idx].size];
            printf("%d\n", last);
        }
    }
    for (int i = 0; i < n; i++) free(seq[i].data);
    free(seq);
    return 0;
}
